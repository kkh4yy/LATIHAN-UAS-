public interface Pembayaran {
    public void bayar(double jumlahBayar);
    public boolean statusLunas();
    public String toString();
}
