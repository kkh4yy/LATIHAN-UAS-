(Acknowledgement: Soal diambil dan sedikit modifikasi dari usulan soal oleh Abelyvia, Diaz dan Theo)

Silahkan ambil template Crazy Eight dari tugas praktikum atau template code yang disediakan di scele. Tambahkan class BankAccount. 

Tentunya dalam prinsip Object Oriented yang baik, anda sepantas nya tidak meng-edit class yang sudah ada tapi anda bisa me-reuse dengan menerapkan inheritance dan menambahkan field tersebut pada sub-class nya. Sehingga anda disarankan membuat class baru yg merupakan sub class dari Player. Pada class baru tersebut tambahkan field bankaccount.

Pastikan program anda masih berjalan baik, namun sekarang bila player-nya memiliki bankAccount, maka bila player tersebut menang, player akan mendapat kan hadiah Rp. 100.000,- . Namun kalau tidak ada bank-account, player tidak mendapat hadiah.

Buat simulasi yang dapat memperlihat bahwa perubahan yang anda buat sudah berjalan baik.

Kriteria Evaluasi:

Nilai 4: Ada Unit test dengan code coverage > 70% dan program berjalan sesuai permintaan
Nilai 3: Program berjalan sesuai permintaan namun unit test tidak ada atau <=70%
Nilai 2: Program bisa di-compile tapi tidak berjalan sesuai permintaan
Nilai 1: Program tidak bisa di-compile.
