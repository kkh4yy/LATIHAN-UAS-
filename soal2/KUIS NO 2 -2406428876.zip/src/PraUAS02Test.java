import org.junit.jupiter.api.Test;

public class PraUAS02Test {
    @Test
    void testMain() {

    }
}
