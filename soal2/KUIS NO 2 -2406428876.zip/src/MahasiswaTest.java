import org.junit.jupiter.api.Test;

public class MahasiswaTest {
    @Test
    void testGetAngkatan() {

    }

    @Test
    void testGetIPK() {

    }

    @Test
    void testGetNama() {

    }

    @Test
    void testToString() {

    }
}
